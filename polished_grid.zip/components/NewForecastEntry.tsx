'use client';

import { useState } from 'react';

interface NewForecastEntryProps {
    onClose: () => void;
    onSuccess: () => void;
}

export default function NewForecastEntry({ onClose, onSuccess }: NewForecastEntryProps) {
    const [formData, setFormData] = useState({
        model: '',
        customer: '',
        standard: '',
        application: '',
        location: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            // Note: Since we are using a CSV as a master database, 
            // the user might want this saved to Supabase or appended to CSV.
            // For now, let's simulate a POST call.
            console.log('Submitting new forecast entry:', formData);
            // In a real implementation, we would call an API that writes to Supabase
            // and then the Forecast API would merge Supabase data with CSV data.
            onSuccess();
        } catch (error) {
            console.error('Error saving entry:', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content" style={{ maxWidth: 500 }}>
                <div className="modal-header">
                    <h2 className="modal-title">New Forecast Entry</h2>
                    <button className="close-btn" onClick={onClose}>&times;</button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="modal-body">
                        <div className="form-group">
                            <label>Model</label>
                            <input 
                                type="text" 
                                className="form-input" 
                                required 
                                value={formData.model}
                                onChange={e => setFormData({ ...formData, model: e.target.value })}
                            />
                        </div>
                        <div className="form-row">
                            <div className="form-group">
                                <label>Customer</label>
                                <input 
                                    type="text" 
                                    className="form-input" 
                                    required 
                                    value={formData.customer}
                                    onChange={e => setFormData({ ...formData, customer: e.target.value })}
                                />
                            </div>
                            <div className="form-group">
                                <label>Standard</label>
                                <input 
                                    type="text" 
                                    className="form-input" 
                                    required 
                                    value={formData.standard}
                                    onChange={e => setFormData({ ...formData, standard: e.target.value })}
                                />
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="form-group">
                                <label>Application</label>
                                <input 
                                    type="text" 
                                    className="form-input" 
                                    required 
                                    value={formData.application}
                                    onChange={e => setFormData({ ...formData, application: e.target.value })}
                                />
                            </div>
                            <div className="form-group">
                                <label>Location</label>
                                <input 
                                    type="text" 
                                    className="form-input" 
                                    required 
                                    value={formData.location}
                                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                        <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                            {isSubmitting ? 'Saving...' : 'Add Entry'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
