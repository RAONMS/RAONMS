'use client';

import React, { useState } from 'react';

interface ModelGroupingProps {
    models: string[];
    onGroupsChange?: (groups: Record<string, string[]>) => void;
}

export default function ModelGrouping({ models, onGroupsChange }: ModelGroupingProps) {
    const [groups, setGroups] = useState<Record<string, string[]>>({
        'Ungrouped': models,
    });
    const [newGroupName, setNewGroupName] = useState('');

    const handleAddGroup = () => {
        if (!newGroupName.trim() || groups[newGroupName]) return;
        setGroups(prev => ({ ...prev, [newGroupName]: [] }));
        setNewGroupName('');
    };

    const onDragStart = (e: React.DragEvent, model: string, fromGroup: string) => {
        e.dataTransfer.setData('model', model);
        e.dataTransfer.setData('fromGroup', fromGroup);
    };

    const onDrop = (e: React.DragEvent, toGroup: string) => {
        const model = e.dataTransfer.getData('model');
        const fromGroup = e.dataTransfer.getData('fromGroup');

        if (fromGroup === toGroup) return;

        setGroups(prev => {
            const next = { ...prev };
            next[fromGroup] = next[fromGroup].filter(m => m !== model);
            next[toGroup] = [...next[toGroup], model].sort();
            
            if (onGroupsChange) onGroupsChange(next);
            return next;
        });
    };

    const allowDrop = (e: React.DragEvent) => {
        e.preventDefault();
    };

    return (
        <div className="grouping-container">
            <div className="grouping-header">
                <h3>Product Grouping</h3>
                <div className="add-group">
                    <input 
                        type="text" 
                        placeholder="New Group Name..." 
                        value={newGroupName}
                        onChange={(e) => setNewGroupName(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddGroup()}
                        className="form-input"
                    />
                    <button className="btn btn-primary" onClick={handleAddGroup}>Add Group</button>
                </div>
            </div>

            <div className="groups-grid">
                {Object.entries(groups).map(([groupName, groupModels]) => (
                    <div 
                        key={groupName} 
                        className={`group-column ${groupName === 'Ungrouped' ? 'ungrouped' : ''}`}
                        onDragOver={allowDrop}
                        onDrop={(e) => onDrop(e, groupName)}
                    >
                        <div className="group-title">
                            {groupName}
                            <span className="count">{groupModels.length}</span>
                        </div>
                        <div className="models-list">
                            {groupModels.length === 0 && (
                                <div className="empty-hint">Drop products here</div>
                            )}
                            {groupModels.map(model => (
                                <div 
                                    key={model} 
                                    className="model-tag"
                                    draggable
                                    onDragStart={(e) => onDragStart(e, model, groupName)}
                                >
                                    <IconDrag />
                                    <span>{model}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            <style jsx>{`
                .grouping-container {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                    height: 100%;
                }
                .grouping-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding-bottom: 12px;
                    border-bottom: 1px solid var(--color-border);
                }
                .add-group {
                    display: flex;
                    gap: 10px;
                }
                .add-group input { width: 200px; }
                
                .groups-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                    gap: 20px;
                    align-items: start;
                }
                
                .group-column {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    display: flex;
                    flex-direction: column;
                    min-height: 300px;
                    box-shadow: var(--shadow-sm);
                }
                .group-column.ungrouped {
                    background: #f8fafc;
                    border-style: dashed;
                }
                
                .group-title {
                    padding: 12px 16px;
                    font-weight: 700;
                    font-size: 14px;
                    border-bottom: 1px solid var(--color-border-light);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .count {
                    font-size: 11px;
                    background: var(--color-bg);
                    padding: 2px 8px;
                    border-radius: var(--radius-full);
                    color: var(--color-text-muted);
                }
                
                .models-list {
                    padding: 12px;
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }
                
                .model-tag {
                    padding: 10px 12px;
                    background: white;
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    font-size: 13px;
                    cursor: grab;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    transition: all 0.2s;
                }
                .model-tag:hover {
                    border-color: var(--color-primary);
                    box-shadow: var(--shadow-md);
                }
                .model-tag:active { cursor: grabbing; }
                
                .empty-hint {
                    text-align: center;
                    color: var(--color-text-light);
                    font-size: 12px;
                    margin-top: 40px;
                    border: 1px dashed var(--color-border);
                    padding: 20px;
                    border-radius: var(--radius-md);
                }
            `}</style>
        </div>
    );
}

function IconDrag() {
    return (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.3 }}>
            <circle cx="9" cy="5" r="1" />
            <circle cx="9" cy="12" r="1" />
            <circle cx="9" cy="19" r="1" />
            <circle cx="15" cy="5" r="1" />
            <circle cx="15" cy="12" r="1" />
            <circle cx="15" cy="19" r="1" />
        </svg>
    );
}
