'use client';

import React from 'react';

interface ForecastGridProps {
    data: any[];
    timeline: string[];
    visibleColumns: {
        standard: boolean;
        application: boolean;
        location: boolean;
    };
    onToggleColumn: (col: 'standard' | 'application' | 'location') => void;
    globalPlanVarVisible: boolean;
    lockedMonths: Set<string>;
    hiddenMonths: Set<string>;
    monthSpecificPlanVar: Record<string, boolean>;
    onToggleLock: (month: string) => void;
    onToggleMonthVisibility: (month: string) => void;
    onToggleMonthPlanVar: (month: string) => void;
}

function formatMonth(ym: string) {
    const [year, month] = ym.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleString('default', { month: 'short', year: '2-digit' });
}

export default function ForecastGrid({ 
    data, 
    timeline,
    visibleColumns, 
    onToggleColumn,
    globalPlanVarVisible,
    lockedMonths,
    hiddenMonths,
    monthSpecificPlanVar,
    onToggleLock,
    onToggleMonthVisibility,
    onToggleMonthPlanVar
}: ForecastGridProps) {
    
    const visibleMonths = timeline.filter(m => !hiddenMonths.has(m));
    const activeIdCols = 2 + (visibleColumns.standard ? 1 : 0) + (visibleColumns.application ? 1 : 0) + (visibleColumns.location ? 1 : 0);

    // Calculate left positions for sticky columns
    const colWidths = {
        model: 150,
        customer: 130,
        standard: 110,
        application: 110,
        location: 100
    };

    let currentLeft = 0;
    const leftModel = 0;
    currentLeft += colWidths.model;
    const leftCustomer = currentLeft;
    currentLeft += colWidths.customer;
    const leftStandard = visibleColumns.standard ? currentLeft : 0;
    if (visibleColumns.standard) currentLeft += colWidths.standard;
    const leftApplication = visibleColumns.application ? currentLeft : 0;
    if (visibleColumns.application) currentLeft += colWidths.application;
    const leftLocation = visibleColumns.location ? currentLeft : 0;
    if (visibleColumns.location) currentLeft += colWidths.location;

    const formatValue = (val: number) => val === 0 ? '-' : val.toLocaleString(undefined, { maximumFractionDigits: 0 });
    const formatAsp = (val: number) => val === 0 ? '-' : val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    return (
        <div className="forecast-grid-container">
            <div className="forecast-table-wrapper">
                <table className="forecast-table">
                    <thead>
                        {/* Row 1: Months / Identifiers Group */}
                        <tr>
                            <th colSpan={activeIdCols} className="sticky-col-header tier-1">Identifiers</th>
                            {visibleMonths.map(m => {
                                const showPlanVar = monthSpecificPlanVar[m] ?? globalPlanVarVisible;
                                return (
                                    <th key={m} colSpan={showPlanVar ? 9 : 3} className="month-header tier-1">
                                        <div className="month-header-content">
                                            <span className="month-label">{formatMonth(m)}</span>
                                            <div className="month-controls">
                                                <button className="ctrl-btn" onClick={() => onToggleLock(m)}>
                                                    {lockedMonths.has(m) ? 'Unlock' : 'Lock'}
                                                </button>
                                                <button className="ctrl-btn" onClick={() => onToggleMonthPlanVar(m)}>
                                                    {showPlanVar ? 'Hide PV' : 'Show PV'}
                                                </button>
                                                <button className="ctrl-btn hide-month-btn" onClick={() => onToggleMonthVisibility(m)}>
                                                    Hide Month
                                                </button>
                                            </div>
                                        </div>
                                    </th>
                                );
                            })}
                        </tr>
                        {/* Row 2: Model, Customer... / Groups (FCST, PLAN, VAR) */}
                        <tr>
                            <th className="sticky-col sticky-col-1 tier-2" style={{ left: leftModel }}>Model</th>
                            <th className="sticky-col sticky-col-2 tier-2" style={{ left: leftCustomer }}>Customer</th>
                            {visibleColumns.standard && <th className="sticky-col sticky-col-3 tier-2" style={{ left: leftStandard }}>Standard</th>}
                            {visibleColumns.application && <th className="sticky-col sticky-col-4 tier-2" style={{ left: leftApplication }}>Application</th>}
                            {visibleColumns.location && <th className="sticky-col sticky-col-5 tier-2" style={{ left: leftLocation }}>Location</th>}
                            
                            {visibleMonths.map(m => {
                                const showPlanVar = monthSpecificPlanVar[m] ?? globalPlanVarVisible;
                                return (
                                    <React.Fragment key={m}>
                                        <th className="group-header fcst tier-2" colSpan={3}>FCST</th>
                                        {showPlanVar && (
                                            <>
                                                <th className="group-header plan tier-2" colSpan={3}>PLAN</th>
                                                <th className="group-header var tier-2" colSpan={3}>VAR</th>
                                            </>
                                        )}
                                    </React.Fragment>
                                );
                            })}
                        </tr>
                        {/* Row 3: Hide Buttons / Metrics (Qty, ASP, Amt) */}
                        <tr>
                            <th className="sticky-col sticky-col-1 tier-3 empty" style={{ left: leftModel }}></th>
                            <th className="sticky-col sticky-col-2 tier-3 empty" style={{ left: leftCustomer }}></th>
                            {visibleColumns.standard && (
                                <th className="sticky-col sticky-col-3 tier-3" style={{ left: leftStandard }}>
                                    <button className="hide-btn" onClick={() => onToggleColumn('standard')}>Hide</button>
                                </th>
                            )}
                            {visibleColumns.application && (
                                <th className="sticky-col sticky-col-4 tier-3" style={{ left: leftApplication }}>
                                    <button className="hide-btn" onClick={() => onToggleColumn('application')}>Hide</button>
                                </th>
                            )}
                            {visibleColumns.location && (
                                <th className="sticky-col sticky-col-5 tier-3" style={{ left: leftLocation }}>
                                    <button className="hide-btn" onClick={() => onToggleColumn('location')}>Hide</button>
                                </th>
                            )}

                            {visibleMonths.map(m => {
                                const showPlanVar = monthSpecificPlanVar[m] ?? globalPlanVarVisible;
                                return (
                                    <React.Fragment key={m}>
                                        <th className="metric-header fcst tier-3">Qty</th>
                                        <th className="metric-header fcst tier-3">ASP</th>
                                        <th className="metric-header fcst tier-3">AMT</th>
                                        {showPlanVar && (
                                            <>
                                                <th className="metric-header plan tier-3">Qty</th>
                                                <th className="metric-header plan tier-3">ASP</th>
                                                <th className="metric-header plan tier-3">AMT</th>
                                                <th className="metric-header var tier-3 mid-metric">Qty</th>
                                                <th className="metric-header var tier-3 mid-metric">ASP</th>
                                                <th className="metric-header var tier-3 last-metric">AMT</th>
                                            </>
                                        )}
                                    </React.Fragment>
                                );
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((row, idx) => (
                            <tr key={idx}>
                                <td className="sticky-col sticky-col-1" style={{ left: leftModel }} title={row.model}>{row.model}</td>
                                <td className="sticky-col sticky-col-2" style={{ left: leftCustomer }} title={row.customer}>{row.customer}</td>
                                {visibleColumns.standard && <td className="sticky-col sticky-col-3" style={{ left: leftStandard }}>{row.standard}</td>}
                                {visibleColumns.application && <td className="sticky-col sticky-col-4" style={{ left: leftApplication }}>{row.application || '-'}</td>}
                                {visibleColumns.location && <td className="sticky-col sticky-col-5" style={{ left: leftLocation }}>{row.location || '-'}</td>}
                                
                                {visibleMonths.map(m => {
                                    const mData = row.data[m] || { fcstQty: 0, fcstAsp: 0, fcstAmt: 0, planQty: 0, planAsp: 0, planAmt: 0 };
                                    const showPlanVar = monthSpecificPlanVar[m] ?? globalPlanVarVisible;
                                    const isLocked = lockedMonths.has(m);
                                    
                                    const varQty = (mData.fcstQty || 0) - (mData.planQty || 0);
                                    const varAsp = (mData.fcstAsp || 0) - (mData.planAsp || 0);
                                    const varAmt = (mData.fcstAmt || 0) - (mData.planAmt || 0);

                                    return (
                                        <React.Fragment key={m}>
                                            <td className={`metric-cell fcst ${isLocked ? 'locked' : ''}`}>{formatValue(mData.fcstQty)}</td>
                                            <td className={`metric-cell fcst ${isLocked ? 'locked' : ''}`}>{formatAsp(mData.fcstAsp)}</td>
                                            <td className={`metric-cell fcst last-metric ${isLocked ? 'locked' : ''}`}>{formatValue(mData.fcstAmt)}</td>
                                            
                                            {showPlanVar && (
                                                <>
                                                    <td className={`metric-cell plan ${isLocked ? 'locked' : ''}`}>{formatValue(mData.planQty)}</td>
                                                    <td className={`metric-cell plan ${isLocked ? 'locked' : ''}`}>{formatAsp(mData.planAsp)}</td>
                                                    <td className={`metric-cell plan last-metric ${isLocked ? 'locked' : ''}`}>{formatValue(mData.planAmt)}</td>
                                                    
                                                    <td className={`metric-cell var mid-metric ${varQty > 0 ? 'pos' : varQty < 0 ? 'neg' : ''} ${isLocked ? 'locked' : ''}`}>{formatValue(varQty)}</td>
                                                    <td className={`metric-cell var mid-metric ${varAsp > 0 ? 'pos' : varAsp < 0 ? 'neg' : ''} ${isLocked ? 'locked' : ''}`}>{formatAsp(varAsp)}</td>
                                                    <td className={`metric-cell var last-metric month-separator ${varAmt > 0 ? 'pos' : varAmt < 0 ? 'neg' : ''} ${isLocked ? 'locked' : ''}`}>{formatValue(varAmt)}</td>
                                                </>
                                            )}
                                            {!showPlanVar && <td className="month-separator" style={{ padding: 0, width: 0, border: 'none' }}></td>}
                                        </React.Fragment>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            <style jsx>{`
                .forecast-grid-container {
                    width: 100%;
                    overflow: hidden;
                    border-radius: var(--radius-lg);
                    background: white;
                    border: 1px solid var(--color-border);
                }
                .forecast-table-wrapper {
                    overflow-x: auto;
                    max-height: 80vh;
                    overflow-y: auto;
                }
                .forecast-table {
                    border-collapse: separate;
                    border-spacing: 0;
                    font-size: 13px;
                    width: max-content;
                }
                .forecast-table th, .forecast-table td {
                    padding: 6px 10px;
                    border-right: 1px solid var(--color-border-light);
                    border-bottom: 1px solid var(--color-border-light);
                    white-space: nowrap;
                }

                /* Separator Logic */
                .month-separator {
                    border-right: 1.5px solid #94a3b8 !important;
                }
                
                .sticky-col {
                    position: sticky;
                    background: white;
                    z-index: 2;
                }
                .sticky-col-header {
                    position: sticky;
                    left: 0;
                    background: #f1f5f9;
                    font-weight: 700;
                    color: var(--color-text);
                    text-align: center;
                    border-right: 1.5px solid #64748b !important;
                }
                
                .tier-1 { top: 0; z-index: 10; height: 50px; }
                .tier-2 { top: 50px; z-index: 10; height: 32px; }
                .tier-3 { top: 82px; z-index: 10; height: 36px; }

                .sticky-col.tier-2, .sticky-col.tier-3 { z-index: 11; }
                .sticky-col-header.tier-1 { z-index: 12; }

                .sticky-col-1 { min-width: 150px; max-width: 150px; overflow: hidden; text-overflow: ellipsis; font-weight: 600; color: var(--color-text); }
                .sticky-col-2 { min-width: 130px; max-width: 130px; overflow: hidden; text-overflow: ellipsis; }
                .sticky-col-3 { min-width: 110px; }
                .sticky-col-4 { min-width: 110px; }
                .sticky-col-5 { min-width: 100px; border-right: 1.5px solid #64748b !important; }
                
                tr:hover td.sticky-col {
                    background: var(--color-surface-hover);
                }

                .month-header {
                    background: #f3f4f6;
                    font-weight: 600;
                    text-align: center;
                    color: var(--color-text);
                    font-size: 11px;
                    border-right: 1.5px solid #94a3b8 !important;
                }
                .month-header-content {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 4px;
                    padding: 4px 0;
                }
                .month-label {
                    font-weight: 700;
                    font-size: 12px;
                    color: var(--color-text);
                }
                .month-controls {
                    display: flex;
                    gap: 4px;
                }
                .ctrl-btn {
                    font-size: 9px;
                    padding: 2px 6px;
                    background: white;
                    border: 1px solid var(--color-border);
                    border-radius: 4px;
                    cursor: pointer;
                    color: var(--color-text-secondary);
                    font-weight: 500;
                    transition: all 0.2s;
                }
                .ctrl-btn:hover {
                    background: var(--color-surface-hover);
                    border-color: var(--color-primary-light);
                }
                .hide-month-btn {
                    color: var(--color-danger);
                    border-color: #fca5a5;
                }
                .hide-month-btn:hover {
                    background: #fee2e2;
                }

                .group-header {
                    font-size: 10px;
                    font-weight: 700;
                    text-align: center;
                    background: #f8fafc;
                }
                .group-header.fcst { color: var(--color-primary); background: #f5f3ff; }
                .group-header.plan { color: var(--color-text-muted); background: #f8fafc; }
                .group-header.var { color: var(--color-text-secondary); background: #f1f5f9; border-right: 1.5px solid #94a3b8 !important; }

                .metric-header {
                    font-size: 9px;
                    font-weight: 700;
                    text-align: right;
                    background: #ffffff;
                    color: var(--color-text-light);
                    min-width: 60px;
                }
                /* Remove thick lines between metrics within a month, except for group transitions if needed */
                .metric-header.mid-metric { border-right: 1px solid var(--color-border-light); }
                .metric-header.last-metric { border-right: 1px solid var(--color-border-light); }
                .metric-header.month-separator { border-right: 1.5px solid #94a3b8 !important; }

                .metric-cell {
                    text-align: right;
                    font-family: 'Inter', monospace;
                    font-size: 11px;
                }
                .metric-cell.fcst { color: var(--color-primary); }
                .metric-cell.plan { color: var(--color-text-muted); }
                .metric-cell.var { font-weight: 500; background: #fafafa; }
                .metric-cell.var.pos { color: var(--color-success); }
                .metric-cell.var.neg { color: var(--color-danger); }
                .metric-cell.mid-metric { border-right: 1px solid var(--color-border-light); }

                .metric-cell.locked {
                    background-color: #f9fafb !important;
                    opacity: 0.7;
                    cursor: not-allowed;
                }

                .hide-btn {
                    font-size: 9px;
                    padding: 2px 6px;
                    background: #fee2e2;
                    color: #b91c1c;
                    border: 1px solid #fca5a5;
                    border-radius: 4px;
                    cursor: pointer;
                }
                .hide-btn:hover { background: #fecaca; }
                .tier-3.empty { border-bottom: 2px solid var(--color-border); }
            `}</style>
        </div>
    );
}
