import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import Papa from 'papaparse';

export const dynamic = 'force-dynamic';

const MONTH_MAP: Record<string, string> = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
    'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
};

function normalizeMonth(m: string): string | null {
    if (!m) return null;
    const clean = m.toLowerCase().replace('.', '').trim();
    const match = clean.match(/([a-z]{3}).*?(\d{2})/);
    if (!match) return null;
    const month = MONTH_MAP[match[1]];
    const year = '20' + match[2];
    if (!month) return null;
    return `${year}-${month}`;
}

export async function GET() {
    try {
        const filePath = path.join(process.cwd(), 'forecast', 'forecast_master_database.csv');
        const csvContent = fs.readFileSync(filePath, 'utf8');

        const parsed = Papa.parse(csvContent, {
            header: true,
            skipEmptyLines: true,
            dynamicTyping: true
        });

        // Structure: Record<Key, MonthData>
        // Key: Model|Customer|Standard|Application|Location
        const rows: any[] = [];
        const seenKeys = new Map<string, number>();

        parsed.data.forEach((row: any) => {
            const key = `${row.Model}|${row.Customer}|${row.Standard}|${row.Application}|${row.Location}`;
            const normalizedMonth = normalizeMonth(row.Month);
            
            if (!normalizedMonth) return;

            if (!seenKeys.has(key)) {
                seenKeys.set(key, rows.length);
                rows.push({
                    model: row.Model,
                    customer: row.Customer,
                    standard: row.Standard,
                    application: row.Application,
                    location: row.Location,
                    data: {}
                });
            }

            const rowIndex = seenKeys.get(key)!;
            rows[rowIndex].data[normalizedMonth] = {
                fcstQty: row["FCST_Q'ty"] || 0,
                fcstAsp: row["FCST_ASP"] || 0,
                fcstAmt: row["FCST_AMT"] || 0,
                planQty: row["PLAN_Q'ty"] || 0,
                planAsp: row["PLAN_ASP"] || 0,
                planAmt: row["PLAN_AMT"] || 0
            };
        });

        return NextResponse.json(rows);
    } catch (error: any) {
        console.error('Forecast API error:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
