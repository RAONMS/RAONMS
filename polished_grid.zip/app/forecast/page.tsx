'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import ForecastGrid from '@/components/ForecastGrid';
import NewForecastEntry from '@/components/NewForecastEntry';
import ModelGrouping from '@/components/ModelGrouping';
import { useHeaderActions } from '@/lib/HeaderActionsContext';

export default function ForecastPage() {
    const [activeTab, setActiveTab] = useState<'grid' | 'settings'>('grid');
    const [isNewEntryOpen, setIsNewEntryOpen] = useState(false);
    const [forecastData, setForecastData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const { setActions } = useHeaderActions();
    
    // Grid States
    const [visibleColumns, setVisibleColumns] = useState({
        standard: true,
        application: true,
        location: true
    });

    const [globalPlanVarVisible, setGlobalPlanVarVisible] = useState(true);
    const [lockedMonths, setLockedMonths] = useState<Set<string>>(new Set());
    const [hiddenMonths, setHiddenMonths] = useState<Set<string>>(new Set());
    const [monthSpecificPlanVar, setMonthSpecificPlanVar] = useState<Record<string, boolean>>({});

    // Dynamic Timeline: Current Year + Next Year (24 months)
    const timeline = useMemo(() => {
        const now = new Date();
        const currentYear = now.getFullYear();
        const months: string[] = [];
        
        for (let y = currentYear; y <= currentYear + 1; y++) {
            for (let m = 1; m <= 12; m++) {
                const monthStr = `${y}-${m.toString().padStart(2, '0')}`;
                months.push(monthStr);
            }
        }
        return months;
    }, []);

    // Default: Locked months (past months) are hidden
    useEffect(() => {
        const nowStr = new Date().toISOString().slice(0, 7);
        const autoLocked = timeline.filter(m => m < nowStr);
        setLockedMonths(new Set(autoLocked));
        setHiddenMonths(new Set(autoLocked));
    }, [timeline]);

    const fetchData = () => {
        setLoading(true);
        fetch('/api/forecast')
            .then(res => res.json())
            .then(data => {
                setForecastData(data);
                setLoading(false);
            })
            .catch(err => {
                console.error('Error fetching forecast data:', err);
                setLoading(false);
            });
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleToggleColumn = useCallback((col: 'standard' | 'application' | 'location') => {
        setVisibleColumns(prev => ({ ...prev, [col]: !prev[col] }));
    }, []);

    const showAllColumns = useCallback(() => {
        setVisibleColumns({ standard: true, application: true, location: true });
    }, []);

    // Logic Fix: Syncing Global Toggle with Local States
    const handleGlobalPlanVarToggle = useCallback(() => {
        const nextState = !globalPlanVarVisible;
        setGlobalPlanVarVisible(nextState);
        // Reset individualOverrides when global is clicked, so all months follow global
        setMonthSpecificPlanVar({});
    }, [globalPlanVarVisible]);

    // Set Header Actions
    useEffect(() => {
        if (activeTab === 'grid') {
            setActions(
                <div style={{ display: 'flex', gap: '8px' }}>
                    <button className="btn btn-secondary" onClick={handleGlobalPlanVarToggle}>
                        {globalPlanVarVisible ? 'Hide' : 'Show'} PLAN/VAR
                    </button>
                    <button className="btn btn-secondary" onClick={showAllColumns}>
                        Show All Columns
                    </button>
                    <button className="btn btn-primary" onClick={() => setIsNewEntryOpen(true)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ width: 15, height: 15 }}>
                            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                        </svg>
                        New Entry
                    </button>
                </div>
            );
        } else {
            setActions(null);
        }
        return () => setActions(null);
    }, [activeTab, setActions, showAllColumns, globalPlanVarVisible, handleGlobalPlanVarToggle]);

    const uniqueModels = useMemo(() => {
        const models = Array.from(new Set(forecastData.map(d => d.model))).sort();
        return models;
    }, [forecastData]);

    const toggleMonthLock = (month: string) => {
        setLockedMonths(prev => {
            const next = new Set(prev);
            if (next.has(month)) next.delete(month);
            else next.add(month);
            return next;
        });
    };

    const toggleMonthVisibility = (month: string) => {
        setHiddenMonths(prev => {
            const next = new Set(prev);
            if (next.has(month)) next.delete(month);
            else next.add(month);
            return next;
        });
    };

    const toggleMonthPlanVar = (month: string) => {
        setMonthSpecificPlanVar(prev => ({
            ...prev,
            [month]: !(prev[month] ?? globalPlanVarVisible)
        }));
    };

    return (
        <div className="page-container">
            <div className={`tabs-container${activeTab === 'grid' ? ' sticky-tabs' : ''}`}>
                <div className="tabs">
                    <button 
                        className={`tab-btn ${activeTab === 'grid' ? 'active' : ''}`}
                        onClick={() => setActiveTab('grid')}
                    >
                        Data Grid
                    </button>
                    <button 
                        className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
                        onClick={() => setActiveTab('settings')}
                    >
                        Settings
                    </button>
                </div>
            </div>

            <main>
                {activeTab === 'grid' ? (
                    <div className="grid-view">
                        {loading ? (
                            <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
                                <p className="text-secondary">Loading forecast data...</p>
                            </div>
                        ) : (
                            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                                <ForecastGrid 
                                    data={forecastData} 
                                    timeline={timeline}
                                    visibleColumns={visibleColumns} 
                                    onToggleColumn={handleToggleColumn}
                                    globalPlanVarVisible={globalPlanVarVisible}
                                    lockedMonths={lockedMonths}
                                    hiddenMonths={hiddenMonths}
                                    monthSpecificPlanVar={monthSpecificPlanVar}
                                    onToggleLock={toggleMonthLock}
                                    onToggleMonthVisibility={toggleMonthVisibility}
                                    onToggleMonthPlanVar={toggleMonthPlanVar}
                                />
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="settings-view">
                        <ModelGrouping models={uniqueModels} />
                    </div>
                )}
            </main>

            {isNewEntryOpen && (
                <NewForecastEntry 
                    onClose={() => setIsNewEntryOpen(false)} 
                    onSuccess={() => {
                        setIsNewEntryOpen(false);
                        fetchData();
                    }}
                />
            )}
            
            <style jsx>{`
                .page-container {
                    display: flex;
                    flex-direction: column;
                    min-height: calc(100vh - var(--topbar-height) - 56px);
                }
                .tabs-container {
                    border-bottom: 2px solid var(--color-border);
                    margin-bottom: 16px;
                    background: var(--color-bg);
                }
                .sticky-tabs {
                    position: sticky;
                    top: -1px;
                    z-index: 20;
                }
                .tabs {
                    display: flex;
                    gap: 2px;
                    margin-bottom: -2px;
                }
                .grid-view, .settings-view {
                    animation: fade-in 0.3s ease-out;
                }
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .btn-secondary {
                    background: #f3f4f6;
                    color: #374151;
                    border: 1px solid #e5e7eb;
                    font-size: 13px;
                    padding: 8px 16px;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 6px;
                }
                .btn-secondary:hover { background: #e5e7eb; }
                .btn-primary {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    font-weight: 600;
                }
            `}</style>
        </div>
    );
}
