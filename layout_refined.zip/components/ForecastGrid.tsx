'use client';

import React from 'react';

interface ForecastGridProps {
    data: any[];
    visibleColumns: {
        standard: boolean;
        application: boolean;
        location: boolean;
    };
}

const MONTHS_2026_2027 = [
    '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', 
    '2026-07', '2026-08', '2026-09', '2026-10', '2026-11', '2026-12',
    '2027-01', '2027-02', '2027-03', '2027-04', '2027-05', '2027-06', 
    '2027-07', '2027-08', '2027-09', '2027-10', '2027-11', '2027-12'
];

function formatMonth(ym: string) {
    const [year, month] = ym.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleString('default', { month: 'short', year: '2-digit' });
}

export default function ForecastGrid({ data, visibleColumns }: ForecastGridProps) {
    const idColCount = 2 + (visibleColumns.standard ? 1 : 0) + (visibleColumns.application ? 1 : 0) + (visibleColumns.location ? 1 : 0);

    // Calculate left positions for sticky columns based on visibility
    const colWidths = {
        model: 150,
        customer: 130,
        standard: 120,
        application: 120,
        location: 100
    };

    let currentLeft = 0;
    const leftModel = 0;
    currentLeft += colWidths.model;
    
    const leftCustomer = currentLeft;
    currentLeft += colWidths.customer;
    
    const leftStandard = visibleColumns.standard ? currentLeft : 0;
    if (visibleColumns.standard) currentLeft += colWidths.standard;
    
    const leftApplication = visibleColumns.application ? currentLeft : 0;
    if (visibleColumns.application) currentLeft += colWidths.application;
    
    const leftLocation = visibleColumns.location ? currentLeft : 0;
    if (visibleColumns.location) currentLeft += colWidths.location;

    return (
        <div className="forecast-grid-container">
            <div className="forecast-table-wrapper">
                <table className="forecast-table">
                    <thead>
                        {/* Row 1: Months */}
                        <tr>
                            <th colSpan={idColCount} rowSpan={2} className="sticky-col-header main-id-header">Identifiers</th>
                            {MONTHS_2026_2027.map(m => (
                                <th key={m} colSpan={3} className="month-header">
                                    {formatMonth(m)}
                                </th>
                            ))}
                        </tr>
                        {/* Row 2: FCST, PLAN, VAR */}
                        <tr>
                            {MONTHS_2026_2027.map(m => (
                                <React.Fragment key={m}>
                                    <th className="group-header fcst">FCST</th>
                                    <th className="group-header plan">PLAN</th>
                                    <th className="group-header var">VAR</th>
                                </React.Fragment>
                            ))}
                        </tr>
                        {/* Sticky Category Headers (Hidden visually but needed for alignment if we had a 3rd row, 
                            but we're following "ONE set of sticky identifier columns" and 2-tier Month->Metrics) 
                            Actually, the requirements say "Top: Month/Year", "Second: FCST, PLAN, VAR".
                            I will use rowSpan for Identifiers.
                        */}
                    </thead>
                    <tbody>
                        {data.map((row, idx) => (
                            <tr key={idx}>
                                <td className="sticky-col sticky-col-1" style={{ left: leftModel }} title={row.model}>{row.model}</td>
                                <td className="sticky-col sticky-col-2" style={{ left: leftCustomer }} title={row.customer}>{row.customer}</td>
                                {visibleColumns.standard && <td className="sticky-col sticky-col-3" style={{ left: leftStandard }}>{row.standard}</td>}
                                {visibleColumns.application && <td className="sticky-col sticky-col-4" style={{ left: leftApplication }}>{row.application || '-'}</td>}
                                {visibleColumns.location && <td className="sticky-col sticky-col-5" style={{ left: leftLocation }}>{row.location || '-'}</td>}
                                
                                {MONTHS_2026_2027.map(m => {
                                    const mData = row.data[m] || { fcstQty: 0, planQty: 0 };
                                    const varQty = (mData.fcstQty || 0) - (mData.planQty || 0);
                                    
                                    const formatValue = (val: number) => val === 0 ? '-' : val.toLocaleString(undefined, { maximumFractionDigits: 0 });

                                    return (
                                        <React.Fragment key={m}>
                                            <td className="metric-cell fcst">{formatValue(mData.fcstQty)}</td>
                                            <td className="metric-cell plan">{formatValue(mData.planQty)}</td>
                                            <td className={`metric-cell var ${varQty > 0 ? 'pos' : varQty < 0 ? 'neg' : ''}`}>
                                                {formatValue(varQty)}
                                            </td>
                                        </React.Fragment>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            <style jsx>{`
                .forecast-grid-container {
                    width: 100%;
                    overflow: hidden;
                    border-radius: var(--radius-lg);
                    background: white;
                    border: 1px solid var(--color-border);
                }
                .forecast-table-wrapper {
                    overflow-x: auto;
                    max-height: 75vh;
                    overflow-y: auto;
                }
                .forecast-table {
                    border-collapse: separate;
                    border-spacing: 0;
                    font-size: 13px;
                    width: max-content;
                }
                .forecast-table th, .forecast-table td {
                    padding: 10px 14px;
                    border-right: 1px solid var(--color-border-light);
                    border-bottom: 1px solid var(--color-border-light);
                    white-space: nowrap;
                }
                .sticky-col {
                    position: sticky;
                    background: white;
                    z-index: 2;
                }
                .main-id-header {
                    z-index: 4;
                    background: #f9fafb !important;
                    border-right: 2px solid var(--color-border) !important;
                    text-align: center;
                    vertical-align: middle;
                }
                .sticky-col-header {
                    position: sticky;
                    top: 0;
                    left: 0;
                    font-weight: 600;
                    color: var(--color-text-secondary);
                }
                
                .sticky-col-1 { min-width: 150px; max-width: 150px; overflow: hidden; text-overflow: ellipsis; font-weight: 600; color: var(--color-text); }
                .sticky-col-2 { min-width: 130px; max-width: 130px; overflow: hidden; text-overflow: ellipsis; }
                .sticky-col-3 { min-width: 120px; }
                .sticky-col-4 { min-width: 120px; }
                .sticky-col-5 { min-width: 100px; border-right: 2px solid var(--color-border) !important; }
                
                tr:hover td.sticky-col {
                    background: var(--color-surface-hover);
                }

                .month-header {
                    position: sticky;
                    top: 0;
                    background: #f3f4f6;
                    font-weight: 600;
                    text-align: center;
                    color: var(--color-text);
                    font-size: 11px;
                    z-index: 3;
                }
                .group-header {
                    position: sticky;
                    top: 35px; /* Height of month header */
                    font-size: 10px;
                    font-weight: 700;
                    text-align: center;
                    background: #f8fafc;
                    border-bottom: 1px solid var(--color-border-light);
                    z-index: 3;
                    min-width: 70px;
                }
                .group-header.fcst { color: var(--color-primary); background: #f5f3ff; }
                .group-header.plan { color: var(--color-text-muted); background: #f8fafc; }
                .group-header.var { color: var(--color-text-secondary); background: #f1f5f9; }

                .metric-cell {
                    text-align: right;
                    font-family: 'Inter', monospace;
                    font-size: 11px;
                }
                .metric-cell.fcst { color: var(--color-primary); }
                .metric-cell.plan { color: var(--color-text-muted); }
                .metric-cell.var { font-weight: 500; background: #fafafa; }
                .metric-cell.var.pos { color: var(--color-success); }
                .metric-cell.var.neg { color: var(--color-danger); }
            `}</style>
        </div>
    );
}
