'use client';

import React, { useState, useEffect, useMemo } from 'react';
import ForecastGrid from '@/components/ForecastGrid';
import NewForecastEntry from '@/components/NewForecastEntry';
import ModelGrouping from '@/components/ModelGrouping';

export default function ForecastPage() {
    const [activeTab, setActiveTab] = useState<'grid' | 'settings'>('grid');
    const [isNewEntryOpen, setIsNewEntryOpen] = useState(false);
    const [forecastData, setForecastData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    
    // Column Visibility State
    const [visibleColumns, setVisibleColumns] = useState({
        standard: true,
        application: true,
        location: true
    });

    const fetchData = () => {
        setLoading(true);
        fetch('/api/forecast')
            .then(res => res.json())
            .then(data => {
                setForecastData(data);
                setLoading(false);
            })
            .catch(err => {
                console.error('Error fetching forecast data:', err);
                setLoading(false);
            });
    };

    useEffect(() => {
        fetchData();
    }, []);

    const uniqueModels = useMemo(() => {
        const models = Array.from(new Set(forecastData.map(d => d.model))).sort();
        return models;
    }, [forecastData]);

    const toggleColumn = (col: keyof typeof visibleColumns) => {
        setVisibleColumns(prev => ({ ...prev, [col]: !prev[col] }));
    };

    return (
        <div className="page-container">
            <header className="page-header">
                <div>
                    <h1 className="page-header-title">Forecast Management</h1>
                    <p className="page-header-sub">24-Month Sales Projection (2026-2027)</p>
                </div>
                <div className="header-actions">
                    <button className="btn btn-primary" onClick={() => setIsNewEntryOpen(true)}>
                        <span>+ New Entry</span>
                    </button>
                </div>
            </header>

            <div className="control-bar">
                <div className="tabs">
                    <button 
                        className={`tab-btn ${activeTab === 'grid' ? 'active' : ''}`}
                        onClick={() => setActiveTab('grid')}
                    >
                        Data Grid
                    </button>
                    <button 
                        className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
                        onClick={() => setActiveTab('settings')}
                    >
                        Settings
                    </button>
                </div>

                {activeTab === 'grid' && (
                    <div className="visibility-toggles">
                        <span className="toggle-label">View Columns:</span>
                        <button 
                            className={`toggle-btn ${visibleColumns.standard ? 'active' : ''}`}
                            onClick={() => toggleColumn('standard')}
                        >
                            Standard
                        </button>
                        <button 
                            className={`toggle-btn ${visibleColumns.application ? 'active' : ''}`}
                            onClick={() => toggleColumn('application')}
                        >
                            Application
                        </button>
                        <button 
                            className={`toggle-btn ${visibleColumns.location ? 'active' : ''}`}
                            onClick={() => toggleColumn('location')}
                        >
                            Location
                        </button>
                    </div>
                )}
            </div>

            <main>
                {activeTab === 'grid' ? (
                    <div className="grid-view">
                        {loading ? (
                            <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
                                <p className="text-secondary">Loading forecast data...</p>
                            </div>
                        ) : (
                            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                                <ForecastGrid data={forecastData} visibleColumns={visibleColumns} />
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="settings-view">
                        <ModelGrouping models={uniqueModels} />
                    </div>
                )}
            </main>

            {isNewEntryOpen && (
                <NewForecastEntry 
                    onClose={() => setIsNewEntryOpen(false)} 
                    onSuccess={() => {
                        setIsNewEntryOpen(false);
                        fetchData();
                    }}
                />
            )}
            
            <style jsx>{`
                .page-container {
                    display: flex;
                    flex-direction: column;
                    min-height: calc(100vh - var(--topbar-height) - 56px);
                }
                .control-bar {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    border-bottom: 2px solid var(--color-border);
                    margin-bottom: 24px;
                }
                .tabs {
                    display: flex;
                    gap: 2px;
                    border-bottom: none;
                    margin-bottom: 0;
                }
                
                .visibility-toggles {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    padding-bottom: 8px;
                }
                .toggle-label {
                    font-size: 12px;
                    font-weight: 600;
                    color: var(--color-text-muted);
                    margin-right: 4px;
                }
                .toggle-btn {
                    padding: 4px 12px;
                    border-radius: var(--radius-full);
                    border: 1px solid var(--color-border);
                    background: white;
                    color: var(--color-text-muted);
                    font-size: 12px;
                    font-weight: 500;
                    transition: all 0.2s;
                    cursor: pointer;
                }
                .toggle-btn:hover {
                    border-color: var(--color-primary);
                    color: var(--color-primary);
                }
                .toggle-btn.active {
                    background: var(--color-primary);
                    color: white;
                    border-color: var(--color-primary);
                    box-shadow: var(--shadow-sm);
                }

                .grid-view, .settings-view {
                    animation: fade-in 0.3s ease-out;
                }
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
}
